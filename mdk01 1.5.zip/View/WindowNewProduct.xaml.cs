﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ShumovV_BD_LR.Model;
using ShumovV_BD_LR.Helper;
using ShumovV_BD_LR.ViewModel;

namespace ShumovV_BD_LR.View

{
    /// <summary>
    /// Логика взаимодействия для WindowNewProduct.xaml
    /// </summary>
    public partial class WindowNewProduct : Window
    {
        public WindowNewProduct()
        {
            InitializeComponent();
        }

        private void BtSave_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что PriceSell - корректное неотрицательное число
            if (!decimal.TryParse(TbPriceSell.Text, out decimal priceSell) || priceSell < 0)
            {
                MessageBox.Show("Цена продажи должна быть положительным числом!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                TbPriceSell.Focus(); // Устанавливаем фокус на поле с ошибкой
                return;
            }
            if (!decimal.TryParse(TbPricePurchase.Text, out decimal PricePurchase) || PricePurchase < 0)
            {
                MessageBox.Show("Цена покупки должна быть положительным числом!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                TbPricePurchase.Focus();
                return;
            }
            else
            {
                DialogResult = true;
            }
        }

        private void TbId_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
