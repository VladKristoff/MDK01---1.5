﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ShumovV_BD_LR.ViewModel;
using System.Collections.ObjectModel;
using ShumovV_BD_LR.Model;
using ShumovV_BD_LR.Helper;

namespace ShumovV_BD_LR.View
{
    /// <summary>
    /// Логика взаимодействия для ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        private ProductViewModel vmProduct;
        private ProductGroupViewModel vmGroup;
        private ObservableCollection<ProductDPO> productDPO;
        private List<ProductGroup> groups;
        public ProductWindow()
        {
            InitializeComponent();
            vmProduct = new ProductViewModel();
            vmGroup = new ProductGroupViewModel();
            groups = vmGroup.ListProductGroup.ToList();
            productDPO = new ObservableCollection<ProductDPO>();

            foreach (var product in vmProduct.ListProduct)
            {
                ProductDPO p = new ProductDPO();
                p = p.CopyFromProduct(product);
                productDPO.Add(p);
            }
            ListViewProduct.ItemsSource = productDPO;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowNewProduct wnProduct = new WindowNewProduct
            {
                Title = "Новый товар",
                Owner = this,
            };
            //Формирование кода товара
            int maxIdProduct = vmProduct.MaxID() + 1;
            ProductDPO pro = new ProductDPO()
            {
                id = maxIdProduct
            };
            wnProduct.DataContext = pro;
            wnProduct.CbGroup.ItemsSource = groups;
            if (wnProduct.ShowDialog() == true)
            {
                ProductGroup g = (ProductGroup) wnProduct.CbGroup.SelectedValue;
                pro.group = g.group;
                productDPO.Add(pro);
                //Добавление нового сотрудника в коллекцию
                Product p = new Product();
                p = p.CopyFromProductDPO(pro);
                vmProduct.ListProduct.Add(p);

                ListViewProduct.ItemsSource = null;
                ListViewProduct.ItemsSource = productDPO;
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            WindowNewProduct wnProduct = new WindowNewProduct
            {
                Title = "Редактирование данных",
                Owner = this,
            };
            ProductDPO proDPO = (ProductDPO) ListViewProduct.SelectedValue;
            ProductDPO tempProDPO;
            if (proDPO != null)
            {
                tempProDPO = proDPO.ShallowCopy();
                wnProduct.DataContext=tempProDPO;
                wnProduct.CbGroup.ItemsSource = groups;
                wnProduct.CbGroup.Text = tempProDPO.group;
                if(wnProduct.ShowDialog() == true)
                {
                    ProductGroup g = (ProductGroup)wnProduct.CbGroup.SelectedValue;
                    proDPO.group = g.group;
                    proDPO.Name = tempProDPO.Name;
                    proDPO.PricePurchase = tempProDPO.PricePurchase;
                    proDPO.PriceSell = tempProDPO.PriceSell;
                    ListViewProduct.ItemsSource = null;
                    ListViewProduct.ItemsSource = productDPO;

                    
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            ProductDPO product = (ProductDPO)ListViewProduct.SelectedItem;
            if (product != null)
            {
                MessageBoxResult result = MessageBox.Show("Удалить данные по товару: \n" + product.Name, "Предупреждение", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
                if (result == MessageBoxResult.OK)
                {
                    //Удаление товара в списке отображаемых данных
                    productDPO.Remove(product);
                    // удаление данных в списке классов
                    Product pro = new Product();
                    pro = pro.CopyFromProductDPO(product);
                    vmProduct.ListProduct.Remove(pro);
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать товар для удаления", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
