﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ShumovV_BD_LR.ViewModel;
using ShumovV_BD_LR.Model;
using System.Net.NetworkInformation;

namespace ShumovV_BD_LR.View
{
    /// <summary>
    /// Логика взаимодействия для ProductGroupWindow.xaml
    /// </summary>
    public partial class ProductGroupWindow : Window
    {
        private ProductGroupViewModel vmProductGroup; // Объявляем как поле класса
        public ProductGroupWindow()
        {
            InitializeComponent();
            DataContext = new ProductGroupViewModel();
            vmProductGroup = new ProductGroupViewModel();
            ListViewProductGroup.ItemsSource = vmProductGroup.ListProductGroup;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowNewGroup wnGroup = new WindowNewGroup
            {
                Title = "Новая группа",
                Owner = this,
            };
            // формирование кода новой должности 
            int maxIdGroup = vmProductGroup.MaxId() + 1;
            ProductGroup group = new ProductGroup()
            {
                id = maxIdGroup,
            };
            wnGroup.DataContext = group;
            if (wnGroup.ShowDialog() == true)
            {
                vmProductGroup.ListProductGroup.Add(group);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            ProductGroup group = (ProductGroup)ListViewProductGroup.SelectedItem;
            if (group != null)
            {
                MessageBoxResult result = MessageBox.Show("Удалить данные по группе: " + group.group, "Предупреждение!", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
                if (result == MessageBoxResult.OK)
                {
                    vmProductGroup.ListProductGroup.Remove(group);
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать группу для удаления", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            WindowNewGroup wnGroup = new WindowNewGroup
            {
                Title = "Редактирование группы",
                Owner = this
            };
            ProductGroup group = (ProductGroup)ListViewProductGroup.SelectedItem;
            if (group != null)
            {
                ProductGroup tempGroup = group.ShallowCopy();
                wnGroup.DataContext = tempGroup;
                if (wnGroup.ShowDialog() == true)
                {
                    group.NameGroup = tempGroup.NameGroup;
                    ListViewProductGroup.ItemsSource = null;
                    ListViewProductGroup.ItemsSource = vmProductGroup.ListProductGroup;
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать группу для редактирования", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
