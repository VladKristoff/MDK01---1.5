﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using MongoDB.Bson.IO;
using Newtonsoft.Json;
using ShumovV_BD_LR.Model;
using ShumovV_BD_LR.Helper;
using ShumovV_BD_LR.View;
using ShumovV_BD_LR.ViewModel;
using JsonConvert = Newtonsoft.Json.JsonConvert;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.DirectoryServices.ActiveDirectory;
using JetBrains.Annotations;

namespace ShumovV_BD_LR.ViewModel
{
    public class ProductGroupViewModel: INotifyPropertyChanged
    {

        private ProductGroup selectedGroup;
        public ProductGroup SelectedGroup
        {
            get
            {
                return selectedGroup;
            }
            set
            {
                selectedGroup = value;
                OnPropertyChanged("SelectedGroup");
                EditGroup.CanExecude(true);
            }
        }
        public ObservableCollection<ProductGroup> ListProductGroup { get; set; } = new ObservableCollection<ProductGroup>();

        public ProductGroupViewModel()
        {
            this.ListProductGroup.Add(new ProductGroup
            {
                id = 1,
                NameGroup = "Овощи"
            });
            this.ListProductGroup.Add(new ProductGroup
            {
                id = 2,
                NameGroup = "Фрукты"
            });
            this.ListProductGroup.Add(new ProductGroup
            {
                id = 3,
                NameGroup = "Ягоды"
            });
        }

        public int MaxId()
        {
            int max = 0;
            foreach (var r in this.ListProductGroup)
            {
                max = r.id;
            };
            return max;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    } 
}