﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShumovV_BD_LR.Model;

namespace ShumovV_BD_LR.ViewModel
{
    public class ProductViewModel
    {
        public ObservableCollection<Product> ListProduct { get; set; } = new ObservableCollection<Product>();

        public ProductViewModel()
        {
            this.ListProduct.Add(
                new Product
                {
                    id = 1,
                    IdGroup = 1,
                    Name = "Огурец",
                    PricePurchase = 20,
                    PriceSell = 25
                });
        }
        public int MaxID()
        {
            int max = 0;
            foreach (var r in this.ListProduct)
            {
                if (max < r.id)
                {
                    max = r.id;
                };
            }
            return max;
        }
    }
}
