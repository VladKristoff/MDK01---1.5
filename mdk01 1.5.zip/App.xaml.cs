﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace ShumovV_BD_LR
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
