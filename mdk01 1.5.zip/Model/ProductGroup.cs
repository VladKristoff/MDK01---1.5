﻿using JetBrains.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ShumovV_BD_LR.Model
{
    public class ProductGroup: INotifyPropertyChanged
    {
        /// <summary>
        /// Код группы
        /// </summary>
        public int id { get; set; }
        /// <summary>
        /// Название группы
        /// </summary>
        private string group;
        /// <summary>
        /// Название группы
        /// </summary>
         public string NameGroup
        {
            get { return group; }
            set {
                group = value;
                OnPropertyChanged("NameGroup");
            }
        }

        public ProductGroup() { }
        public ProductGroup(int id, string group)
        {
            this.id = id;
            this.NameGroup = group;
        }

        public ProductGroup ShallowCopy()
        {
            return (ProductGroup)this.MemberwiseClone();
        }

        /// <summary>
        /// Метод поверхносного копирования
        /// </summary>
        /// <returns></returns>

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName]
        string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
