﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using ShumovV_BD_LR.Helper;
using ShumovV_BD_LR.ViewModel;

namespace ShumovV_BD_LR.Model
{
    public class Product
    {
        public int id { get; set; }
        public int IdGroup {  get; set; } 
        public string Name { get; set; }
        public int PriceSell { get; set; }
        public int PricePurchase { get; set; }
        public Product() { }
        public Product(int id, int IdGroup, string Name, int PriceSell, int PricePurchase)
        {
            this.id = id;
            this.IdGroup = IdGroup;
            this.Name = Name;
            this.PriceSell = PriceSell;
            this.PricePurchase = PricePurchase;
        }

        public Product CopyFromProductDPO(ProductDPO p)
        {
            ProductGroupViewModel vmGroup = new ProductGroupViewModel();
            int GroupId = 0;
            foreach (var r in vmGroup.ListProductGroup)
            {
                if (r.group == p.group)
                {
                    GroupId = r.id;
                    break;
                }
            }
            if (GroupId != 0)
            {
                this.id = p.id;
                this.IdGroup = GroupId;
                this.Name = p.Name; 
                this.PriceSell = p.PriceSell;
                this.PricePurchase = p.PricePurchase;
            }
            return this;
        }

    }
}
