﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ShumovV_BD_LR.Model;

namespace ShumovV_BD_LR.Helper
{
    public class FindGroup
    {
        int id;
        public FindGroup(int id)
        {
            this.id = id;
        }
        public bool GroupPredicate(ProductGroup group)
        {
            return group.id == id;
        }
    }
}
