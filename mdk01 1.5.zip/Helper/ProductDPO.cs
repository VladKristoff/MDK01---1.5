﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using ShumovV_BD_LR.Model;
using ShumovV_BD_LR.ViewModel;
using JetBrains.Annotations;

namespace ShumovV_BD_LR.Helper
{
    public class ProductDPO : INotifyPropertyChanged
    {
        public int id { get; set; }

        /// <summary>
        /// Товарная группа
        /// </summary>
        private string _groupName;
        public string GroupName
        {
            get { return _groupName; }
            set { _groupName = value;
                OnPropertyChanged("GroupName");
            }
        }

        /// <summary>
        /// Название товара
        /// </summary>
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value;
                OnPropertyChanged("Name");
            }
        }


        /// <summary>
        /// Цена продажи
        /// </summary>
        private int priceSell;
        public int PriceSell
        {
            get { return priceSell; }
            set
            {
                priceSell = value;
                OnPropertyChanged("PriceSell");
            }
        }

        /// <summary>
        /// Цена покупки
        /// </summary>
        private int pricePurchase;
        public int PricePurchase
        {
            get { return pricePurchase; }
            set
            {
                pricePurchase = value;
                OnPropertyChanged("PricePurchase");
            }
        }

        public ProductDPO() { }
        public ProductDPO(int id, string group, string name, int priceSell, int pricePurchase)
        {
            this.id = id;
            this.GroupName = group;
            this.Name = name;
            this.PriceSell = priceSell;
            this.PricePurchase = pricePurchase;
        }

        public ProductDPO ShallowCopy()
        {
            return (ProductDPO)this.MemberwiseClone();
        }

        public ProductDPO CopyFromProduct(Product product)
        {
            ProductDPO proDPO = new ProductDPO();
            ProductGroupViewModel vmGroup = new ProductGroupViewModel();
            string group = string.Empty;
            foreach (var r in vmGroup.ListProductGroup)
            {
                if (r.id == product.IdGroup)
                {
                    group = r.NameGroup;
                    break;
                }
            }
            if (group != string.Empty)
            {
                proDPO.id = product.id;
                proDPO.GroupName = group;
                proDPO.Name = product.Name;
                proDPO.PricePurchase = product.PricePurchase;
                proDPO.PriceSell = product.PriceSell;
            }
            return proDPO;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
